package com.example.proyectoIntegrador_Vanetta_Agustin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoIntegradorVanettaAgustinApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoIntegradorVanettaAgustinApplication.class, args);
	}

}
