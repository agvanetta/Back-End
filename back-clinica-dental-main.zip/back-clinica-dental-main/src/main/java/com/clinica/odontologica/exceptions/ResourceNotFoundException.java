package com.clinica.odontologica.exceptions;

public class ResourceNotFoundException  extends Exception{

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
