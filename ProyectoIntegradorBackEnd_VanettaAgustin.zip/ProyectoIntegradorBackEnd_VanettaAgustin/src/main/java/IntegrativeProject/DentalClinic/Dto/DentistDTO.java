package IntegrativeProject.DentalClinic.Dto;

import lombok.Data;

@Data
public class DentistDTO {

    private Integer id;
    private String name;
    private String lastname;
    private Integer register;
}



