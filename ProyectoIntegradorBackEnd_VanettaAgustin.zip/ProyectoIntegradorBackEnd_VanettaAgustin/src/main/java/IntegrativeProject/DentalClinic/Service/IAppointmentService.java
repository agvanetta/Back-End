package IntegrativeProject.DentalClinic.Service;

import IntegrativeProject.DentalClinic.Dto.AppointmentDTO;

public interface IAppointmentService extends ICRUDService<AppointmentDTO> {
}
