package IntegrativeProject.DentalClinic.Service;

import IntegrativeProject.DentalClinic.Dto.DentistDTO;

public interface IDentistService extends ICRUDService<DentistDTO> {
}
