package IntegrativeProject.DentalClinic.Entities;

public enum UserRoles {
    USER,ADMIN
}
