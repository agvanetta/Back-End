package IntegrativeProject.DentalClinic.Service;

import IntegrativeProject.DentalClinic.Dto.PatientDTO;

public interface IPatientService extends ICRUDService<PatientDTO> {

}
