package com.example.apiRestII;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestIiApplicationTests {

	@Test
	void contextLoads() {
	}

}
