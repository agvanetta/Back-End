package com.example.apiRestII;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestIiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestIiApplication.class, args);
	}

}
